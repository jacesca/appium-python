platformName="Windows 10"
bName="chrome"
bVersion="latest"

url="http://www.dummypoint.com/seleniumtemplate.html"
title="Selenium Template --DummyPoint"